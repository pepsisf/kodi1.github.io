Readme for Kodi (XMBC) https://mytv.bg Addon,
crated by i.georgiev@mytv.bg

Readme for Kodi neterratv plugin created mr.olix@gmail.com

How to install:

1. Copy the zip file plugin.video.neterratv-x.x.x.zip to a directory Kodi has access to 
	e.g. <USERDIR>\AppData\Roaming\Kodi\addons\packages\
2. Run Kodi and go to System -> Add-ons
3. From Add-ons menu select -> Install from zip file
4. Select the zip file plugin.video.neterratv-x.x.x.zip
5. NeterraTV add-on will appear in the video addon list
6. Before you run it you have to provide login information
	For this select the addon in the list and the PC use right mouse button 
	on AppleTV long press Menu on the remote control


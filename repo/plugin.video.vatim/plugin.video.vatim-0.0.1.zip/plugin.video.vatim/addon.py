# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib
import urllib2
import cookielib
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.vatim'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.vatim')
username = __settings__.getSetting('username')
password = __settings__.getSetting('password')
logged_in = False
cj = cookielib.CookieJar()
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0' #За симулиране на заявка от компютърен браузър
LG = 'http://vatim.xyz/Account/Login?AspxAutoDetectCookieSupport=1'
RF = 'http://vatim.xyz/'




#Генериране на сесия
def LOGIN():
    global cj
    global logged_in
    
    req = urllib2.Request(LG)
    req.add_header('User-Agent', UA)
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    response = opener.open(req)
    data=response.read()
    response.close()
    
    matcht = re.compile('<input name="__RequestVerificationToken" type="hidden" value="(.+?)" />').findall(data)
    for rvt in matcht:
        try:
            req = urllib2.Request(LG, '__RequestVerificationToken='+rvt+'&email='+username.replace('@','%40')+'&password='+password)
            req.add_header('User-Agent', UA)
            req.add_header('Referrer', LG)
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
            response = opener.open(req)
            data2=response.read()
            response.close()
            #print cj
            #print data2
            logged_in = True
        except:
            xbmcgui.Dialog().ok('VATIM','Възникна проблем в Login функцията. Съобщете на разработчика за проблема!')





#Меню с директории в приставката
def CATEGORIES():
        #if (username is not "" and logged_in == False):
        #    LOGIN()
            #print cj
        #if (logged_in == True):
        #    xbmcgui.Dialog().ok('VATIM','Логнат си :)')
        #else:
        #    xbmcgui.Dialog().ok('VATIM','Не си Логнат :(')
        addDir('Каталог Сериали','http://vatim.xyz/Catalog',1,'http://vatim.xyz/Images/logo1.png')
        addLink('Vatim TV','/TV',3,'http://vatim.xyz/Images/Serials/idx/vatimtv-1.jpg')
        addLink('Лабиринт','/Labyrinth',3,'http://vatim.xyz/Images/Serials/labyrinth/labyrinth-bg.jpg')
        addLink('Лапута: Замък в небето','/Laputa',3,'http://vatim.xyz/Images/Serials/laputa/laputa1.jpg')



#Разлистване на заглавията
def INDEXCAT(url):
        #if (username is not "" and logged_in == False):
        #    LOGIN()
        
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        response = opener.open(req)
        #print 'request page url:' + url
        data=response.read()
        response.close()
        
        #print data
        #Начало на обхождането
        #data = "".join(data.split()) #Изчистваме всички интервали и нови редове
        data = data.replace('\n', '').replace('\r', '')
        #print data
        match = re.compile('<div class=\"pic\">.{3,10}<a href=\"(.+?)\" title=\"(.+?)\">.{15,100}src=\"(.+?)\"').findall(data)
        for alink, title, poster in match:
            #print title.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
            poster = 'http://vatim.xyz' + poster
            addDir(title.decode('utf-8', 'ignore').encode('utf-8', 'ignore'),'http://vatim.xyz'+urllib.quote(alink).decode('utf-8', 'ignore').encode('utf-8', 'ignore'),2,poster)
            #print alink
        #Край на обхождането
        addDir('Наръчник на Геймъра Сезон 1','http://vatim.xyz/Gamer/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/gameri1.jpg')
        addDir('Наръчник на Геймъра Сезон 2','http://vatim.xyz/Gamer/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/gameri1.jpg')
        addDir('Най-добри приятели завинаги Сезон 1','http://vatim.xyz/Best-Friends-Whenever/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/bfw1.jpg')
        addDir('Най-добри приятели завинаги Сезон 2','http://vatim.xyz/Best-Friends-Whenever/S2/E1',2,'http://vatim.xyz/Images/Serials/idx/bfw1.jpg')
        #addDir('Райли в големия свят Сезон 1','http://vatim.xyz/Girl-Meets-World/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/raili.jpg')
        addDir('Райли в големия свят Сезон 2','http://vatim.xyz/Girl-Meets-World/S2/E1',2,'http://vatim.xyz/Images/Serials/idx/raili.jpg')
        addDir('Райли в големия свят Сезон 3','http://vatim.xyz/Girl-Meets-World/S3/E1',2,'http://vatim.xyz/Images/Serials/idx/raili.jpg')
        addDir('Кейси под прикритие Сезон 1','http://vatim.xyz/KC_Undercover/S1/E1',2,'http://vatim.xyz/Images/Serials/KC-Undercover/keisi-12.jpg')


#Разлистване на епизодите
def INDEXPAGES(name,url):
        #if (username is not "" and logged_in == False):
        #    LOGIN()
        
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        req.add_header('Referrer', RF)
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        response = opener.open(req)
        #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM opening ','http://vatim.xyz'+url, 4000, 'DefaultFolder.png'))
        data=response.read()
        response.close()
        
        #Начало на обхождането
        data = data.replace('\n', '').replace('\r', '')
        #print data
        matchf = re.compile('<p class="description">(.+?)</p>').findall(data)
        for fullname in matchf:
            sename = fullname[::1]
        match = re.compile('<li>.{5,16}<a href=\"(.+?)\" {1,5}title=\"(.+?)\">.{15,150}src=\"(.+?)\"').findall(data)
        for alink, title, poster in match:
            #print title.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
            poster = 'http://vatim.xyz' + poster.replace('..','')
            if '<' not in title.decode('utf-8', 'ignore').encode('utf-8', 'ignore'):
                if (sename and 'Сезон' not in title):
                    addLink(title.decode('utf-8', 'ignore').encode('utf-8', 'ignore').replace('Епизод', sename.decode('utf-8', 'ignore').encode('utf-8', 'ignore')+' Епизод'),urllib.quote(alink),3,poster)
                else:
                    addLink(title.decode('utf-8', 'ignore').encode('utf-8', 'ignore'),urllib.quote(alink),3,poster)
                #print alink
        #Край на обхождането
        
        #Превключване между Сезони
        if ("/S1/E1" in url and "<h3> Сезон 2</h3>" in data):
            addDir('Сезон 2 >>',url.replace('/S1/E1','/S2/E1'),2,'DefaultFolder.png')
        if ("<h2> Сезон 2</h2>" in data):
            matchs = re.compile('<li>.{5,16}<a href=\"(.+?)\" {1,5}title=\"(.+?)\">.{15,150}src=\"(.+?)\"').findall(data)
            for alink, title, poster in match:
                if 'Сезон-2' in title:
                    poster = 'http://vatim.xyz' + poster.replace('..','')
                    addDir('Сезон 2 >>','http://vatim.xyz'+urllib.quote(alink),2,'DefaultFolder.png')
        if ("/S2/E1" in url and "<h3> Сезон 3</h3>" in data):
            addDir('Сезон 3 >>',url.replace('/S2/E1','/S3/E1'),2,'DefaultFolder.png')
        if ("<h2> Сезон 3</h2>" in data):
            matchs = re.compile('<li>.{5,16}<a href=\"(.+?)\" {1,5}title=\"(.+?)\">.{15,150}src=\"(.+?)\"').findall(data)
            for alink, title, poster in match:
                if 'Сезон-3' in title:
                    poster = 'http://vatim.xyz' + poster.replace('..','')
                    addDir('Сезон 3 >>','http://vatim.xyz'+urllib.quote(alink),2,'DefaultFolder.png')
        if ("/S3/E1" in url and "<h3> Сезон 4</h3>" in data):
            addDir('Сезон 4 >>',url.replace('/S3/E1','/S4/E1'),2,'DefaultFolder.png')
        if ("/S4/E1" in url and "<h3> Сезон 5</h3>" in data):
            addDir('Сезон 5 >>',url.replace('/S4/E1','/S5/E1'),2,'DefaultFolder.png')
        
        
        






#Зареждане на видео или ТВ
def PLAY(name,url,iconimage):
        if (username is not "" and logged_in == False):
            LOGIN()
        
        #Подготвяне на епизодите
        req = urllib2.Request('http://vatim.xyz'+url)
        req.add_header('User-Agent', UA)
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        response = opener.open(req)
        #print 'request page url: http://vatim.xyz' + url
        #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM opening ','http://vatim.xyz'+url, 4000, 'DefaultFolder.png'))
        data=response.read()
        response.close()
        
        #print data

        #Извличане на видеото
        if 'pcloud.com' in data:
            matche = re.compile('data-src=\"(.+?)\"').findall(data)
            for pcloudf in matche:
                req = urllib2.Request(pcloudf)
                req.add_header('User-Agent', UA)
                opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
                response = opener.open(req)
                #print 'request page url: ' + pcloudf
                #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM opening ',pcloudf, 4000, 'DefaultFolder.png'))
                data2=response.read()
                response.close()
                
                matchv = re.compile('downloadlink\": \"(.+?)\",').findall(data2)
                for vlink in matchv:
                    stream = vlink.replace('\/','/')
        elif 'vbox7.com' in data:
            matchv = re.compile('iframe.{5,30}src=\"(.+?)\"').findall(data)
            for pvlink in matchv:
                req = urllib2.Request(pvlink.replace('vbox7.com/emb/external.php?vid=','vbox7.com/etc/ext.do?key='))
                req.add_header('User-Agent', UA)
                response = urllib2.urlopen(req)
                data2=response.read()
                response.close()
                
                match2 = re.compile('flv_addr=(.+?)&').findall(data)
                for vlink in match2:
                    stream = vlink
        elif 'iframe' in data:
            matche = re.compile('iframe.{5,30}src=\"(.+?)\"').findall(data)
            for iframe in matche:
                req = urllib2.Request('http://vatim.xyz'+iframe)
                req.add_header('User-Agent', UA)
                opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
                response = opener.open(req)
                #print 'request page url: http://vatim.xyz' + iframe
                #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM opening ','http://vatim.xyz'+iframe, 4000, 'DefaultFolder.png'))
                data2=response.read()
                response.close()
                
                data2 = data2.replace('\n', '').replace('\r', '')
                if 'file' in data2:
                    matchv = re.compile('file: \"(.+?)\".{30,50}image:\"(.+?)\".{5,15}title: \"(.+?)\"').findall(data2)
                    for vlink, poster, title in matchv:
                        stream = vlink
                        iconimage = 'http://vatim.xyz' + poster
                else:
                    matchv = re.compile('src.{1,4}\"(.+?)\" }').findall(data2)
                    for vlink in matchv:
                        stream = vlink
        
                
        elif 'file:' in data:
            matchv = re.compile('file:.{1,4}\"(.+?)\"').findall(data)
            for vlink in matchv:
                stream = vlink
        elif 'src:' in data:
            matchv = re.compile('src:.{1,4}\"(.+?)\"').findall(data)
            for vlink in matchv:
                stream = vlink
        if 'source src' in data:
            matchv = re.compile('<source src=\"(.+?)\"').findall(data)
            for vlink in matchv:
                stream = vlink
        
        #Осигуряване на обложка
        matchcover = re.compile('<img src=\"(.+jpg)\"').findall(data)
        for cover in matchcover:
            iconimage = 'http://vatim.xyz' + cover[::1]
            #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM cover ',iconimage, 4000, iconimage))
        
        #Възпроизвеждане на видеото
        li = xbmcgui.ListItem(iconImage=iconimage, thumbnailImage=iconimage, path=stream+'|User-Agent='+UA+'&Referer=http://vatim.xyz'+url)
        li.setInfo('video', { 'title': name })
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
            







#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        #xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        name=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
        CATEGORIES()
    
elif mode==1:
        INDEXCAT(url)

elif mode==2:
        INDEXPAGES(name,url)

elif mode==3:
        PLAY(name,url,iconimage)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
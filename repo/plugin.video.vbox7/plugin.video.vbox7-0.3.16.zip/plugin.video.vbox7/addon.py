# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import time
import urllib
import urllib2
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.vbox7'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.vbox7')

#Настройка качеството на видеото
quality =__settings__.getSetting('quality')
if quality =='0':
	qualityset='default'
elif quality =='1':
	qualityset='240p'
elif quality =='2':
	qualityset='480p'
elif quality =='3':
	qualityset='720p'
elif quality =='4':
	qualityset='1080p'
else:
	qualityset='default'

#Прочита VBOX7 потребителското име от настройките на приставката
uname1 = __settings__.getSetting("username1")
uname2 = __settings__.getSetting("username2")
uname3 = __settings__.getSetting("username3")
uname4 = __settings__.getSetting("username4")
uname5 = __settings__.getSetting("username5")
uname6 = __settings__.getSetting("username6")
uname7 = __settings__.getSetting("username7")
uname8 = __settings__.getSetting("username8")

md = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")
search_path = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/vbox7.search.txt")
kolekcii_path = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/vbox7.playlist.txt")
srtsubs_path = xbmc.translatePath('special://temp/vbox7.Bulgarian.srt')
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:58.0) Gecko/20100101 Firefox/58.0' #За симулиране на заявка от  компютърен браузър

api4 = 'http://api.vbox7.com/v4/?action='
token4 = '&app_token=imperia_android_0.1.0_3rG7jk'


#Меню с директории в приставката
def CATEGORIES():
		addLink('Зареди видео по неговото ID','VOD',0,0,7,md+'DefaultMovies.png')
		addDir('Търси видео във VBOX7','r_video_search&query=',3,md+'DefaultAddonsSearch.png')
		addDir('Търси плейлисти/колекции във VBOX7','https://www.vbox7.com/xpose/search/search.do?ajax=1&order=name&type=playlist&q=',5,md+'DefaultAddonsSearch.png')
		addDir('Списък канали','r_channels',12,md+'DefaultGenre.png')
		addDir('Класации на VBOX7','url',9,md+'DefaultFolder.png')
		addDir('Каталог игрални филми','r_user_collection&id=1786738&page=1',1,md+'DefaultStudios.png')
		addDir('Каталог документални филми','r_user_collection&id=1807205&page=1',1,md+'DefaultStudios.png')
		addDir('Каталог детски филми','r_user_collection&id=1958423&page=1',1,md+'DefaultStudios.png')
		addDir('Каталог детски сериали','r_user_collections&username=vatim&page=1',4,md+'DefaultStudios.png')
		addDir('Каталог корейски сериали','cks',11,md+'DefaultMovieTitle.png')
		addDir('Каталог KPOP клипове','r_user_collection&id=1552349&page=1',1,md+'DefaultMusicSongs.png')
		#Функции изискващи посочен акаунт
		if uname1:
			addDir('Клипове, плейлисти и абонаменти на '+uname1,uname1,10,md+'DefaultActor.png')
		else:
			addLink('Въведете VBOX7 username1 в настройките','VBOX7',0,0,8,md+'DefaultActor.png')
		if uname2:
			addDir('Клипове, плейлисти и абонаменти на '+uname2,uname2,10,md+'DefaultActor.png')
		if uname3:
			addDir('Клипове, плейлисти и абонаменти на '+uname3,uname3,10,md+'DefaultActor.png')
		if uname4:
			addDir('Клипове, плейлисти и абонаменти на '+uname4,uname4,10,md+'DefaultActor.png')
		if uname5:
			addDir('Клипове, плейлисти и абонаменти на '+uname5,uname5,10,md+'DefaultActor.png')
		if uname6:
			addDir('Клипове, плейлисти и абонаменти на '+uname6,uname6,10,md+'DefaultActor.png')
		if uname7:
			addDir('Клипове, плейлисти и абонаменти на '+uname7,uname7,10,md+'DefaultActor.png')
		if uname8:
			addDir('Клипове, плейлисти и абонаменти на '+uname8,uname8,10,md+'DefaultActor.png')
		
		

#Подменю класации
def KLASATZII(url):
	#addDir('Избор на редактора','r_video_editor_selection',1,md+'DefaultActor.png')
	addDir('Видео поток','r_screen_home',1,md+'DefaultFolder.png')
	addDir('Нова Музика','r_screen_new_music&limit=100',1,md+'DefaultMusicSongs.png')
	addDir('Популярни днес','r_video_popular&page=1',1,md+'DefaultFolder.png')
	addDir('100 Популярни','r_screen_popular&limit=100',1,md+'DefaultFolder.png')
	addDir('ТОП 40','r_video_top40',1,md+'DefaultFolder.png')
	addDir('ТОП 40 авторски','r_video_top40_authors',1,md+'DefaultFolder.png')
	addDir('ТОП 40 BG POP','r_video_top40_bgpop',1,md+'DefaultMusicSongs.png')
	addDir('ТОП 40 BG POP FOLK','r_video_top40_bgpopfolk',1,md+'DefaultMusicSongs.png')
	addDir('ТОП 40 авто и спорт','r_video_top40_by_category&category=avtosport',1,md+'DefaultFolder.png')
	addDir('ТОП 40 смях','r_video_top40_by_category&category=smiah',1,md+'DefaultFolder.png')
	addDir('ТОП 40 новини','r_video_top40_by_category&category=novini',1,md+'DefaultFolder.png')
	addDir('ТОП 40 любопитно','r_video_top40_by_category&category=lubopitno',1,md+'DefaultFolder.png')
	addDir('ТОП 40 аниме и AMV','r_video_top40_by_category&category=anime',1,md+'DefaultFolder.png')
	addDir('ТОП 40 ТВ и ШОУ','r_video_top40_tvshow',1,md+'DefaultFolder.png')
	addDir('ТОП 100','r_video_top100',1,md+'DefaultFolder.png')

#Подменю функции изискващи акаунт
def USERV(uname):
	addDir('Клипове на '+uname,'r_user_videos&username='+uname+'&page=1',1,md+'DefaultActor.png')
	addDir('Клипове на '+uname+' на фокус','r_user_focus_videos&username='+uname+'&page=1',1,md+'DefaultActor.png')
	addDir('Любими клипове на '+uname,'r_user_favourites&username='+uname+'&page=1',1,md+'DefaultActor.png')
	addDir('Плейлисти на '+uname,'r_user_collections&username='+uname+'&page=1',4,md+'DefaultActor.png')
	addDir('Абонаменти на '+uname,'r_user_subscription_videos&username='+uname+'&page=1',1,md+'DefaultActor.png')


#Разлистване на заглавията в директория
def INDEX(url):
		try:
			#http://api.vbox7.com/v4/?action=r_video_top40_tvshow&app_token=imperia_android_0.0.7_4yxmKd
			jsonrsp = json.loads('{'+urllib2.urlopen(api4 + url + token4).read().split('{', 1)[-1].split('\n', 1)[0])
			print api4 + url + token4
			#print jsonrsp
			indexcounter = len(jsonrsp['items'])
			try:
				for index in range(0, indexcounter):
					#print jsonrsp['items'][index]['video_title'].encode('utf-8', 'ignore')
					addLink(jsonrsp['items'][index]['video_title'].encode('utf-8', 'ignore'),jsonrsp['items'][index]['video_mdkey'],jsonrsp['items'][index]['video_duration'],jsonrsp['items'][index]['video_is_hd'],2,jsonrsp['items'][index]['video_thumbnails']['big'])
			except:
				for index in range(0, indexcounter):
					#print jsonrsp['items'][index]['item_title'].encode('utf-8', 'ignore')
					addLink(jsonrsp['items'][index]['item_title'].encode('utf-8', 'ignore'),jsonrsp['items'][index]['item_mdkey'],jsonrsp['items'][index]['item_duration'],jsonrsp['items'][index]['item_is_hd'],2,jsonrsp['items'][index]['item_thumbnails']['big'])
			
			#Ако имаме още страници...
			if 'page=' in url and indexcounter > 14:
				lisearch = re.compile('(.+?)&page=(.+?)').findall(url)
				for baseurl,page in lisearch:
					page = int(page) + 1
					url = baseurl + '&page=' + str(page)
					url = url.encode('utf-8')
				addDir('следваща страница>>',url,1,md+'DefaultFolder.png')
		except:
			xbmc.executebuiltin("Notification(VBOX7,Няма връзка със сървъра!,4000)")
			addDir('Включете интернет връзката и опитайте отново','','',md+"DefaultIconError.png")

#Разлистване заглавията на отделните плейлисти
def INDEXCOLLECTIONS(url):
		try:
			#http://api.vbox7.com/v4/?action=r_user_collections&username=mrnkaloto&page=1&app_token=imperia_android_0.0.7_4yxmKd'
			jsonrsp = json.loads('{'+urllib2.urlopen(api4 + url + token4).read().split('{', 1)[-1].split('\n', 1)[0])
			#print jsonrsp
			indexcounter = len(jsonrsp['items'])
			for index in range(0, indexcounter):
				#print jsonrsp['items'][index]['collection_title'].encode('utf-8', 'ignore')
				addDir(jsonrsp['items'][index]['collection_title'].encode('utf-8', 'ignore'),'r_user_collection&id=' + str(jsonrsp['items'][index]['collection_id']) + '&page=1',1,jsonrsp['items'][index]['collection_thumbnail'][0])
			
			#Ако имаме още страници...
			if indexcounter > 14:
				lisearch = re.compile('(.+?)&page=(.+?)').findall(url)
				for baseurl,page in lisearch:
					page = int(page) + 1
					url = baseurl + '&page=' + str(page)
					url = url.encode('utf-8')
				addDir('следваща страница>>',url,4,md+'DefaultFolder.png')
		except:
			xbmc.executebuiltin("Notification(VBOX7,Няма връзка със сървъра!,4000)")
			addDir('Включете интернет връзката и опитайте отново','','',md+"DefaultIconError.png")






#Разлистване каналите с потребители
def LISTCHANNELS(url):
		try:
			#http://api.vbox7.com/v4/?action=r_channels&app_token=imperia_android_0.1.0_3rG7jk
			jsonrsp = json.loads('{'+urllib2.urlopen(api4 + url + token4).read().split('{', 1)[-1].split('\n', 1)[0])
			#print jsonrsp
			indexcounter1 = len(jsonrsp['items']) #брой канали
			for index in range(0, indexcounter1):
				addDir(jsonrsp['items'][index]['channel_name'].encode('utf-8', 'ignore'),str(jsonrsp['items'][index]['channel_id']),13,md+'DefaultFolder.png')
			
		except:
			xbmc.executebuiltin("Notification(VBOX7,Няма връзка със сървъра!,4000)")
			addDir('Включете интернет връзката и опитайте отново','','',md+"DefaultIconError.png")






#Разлистване потребителите в каналите
def LISTUSERS(url):
		try:
			#http://api.vbox7.com/v4/?action=r_channels&app_token=imperia_android_0.1.0_3rG7jk
			jsonrsp = json.loads('{'+urllib2.urlopen(api4 + 'r_channels' + token4).read().split('{', 1)[-1].split('\n', 1)[0])
			#print jsonrsp
			indexcounter1 = len(jsonrsp['items']) #брой канали
			for index in range(0, indexcounter1):
			#print jsonrsp['items'][index]['channel_id']
			#print 'url is: '+url
				if (url == str(jsonrsp['items'][index]['channel_id'])):
					indexcounter2 = len(jsonrsp['items'][index]['channel_items']['items']) #брой потребители в канала
					for index2 in range(0, indexcounter2):
						addDir(jsonrsp['items'][index]['channel_items']['items'][index2]['user_name'].encode('utf-8', 'ignore'),jsonrsp['items'][index]['channel_items']['items'][index2]['user_name'].encode('utf-8', 'ignore'),10,jsonrsp['items'][index]['channel_items']['items'][index2]['user_avatars']['medium'])
				
		except:
			xbmc.executebuiltin("Notification(VBOX7,Няма връзка със сървъра!,4000)")
			addDir('Включете интернет връзката и опитайте отново','','',md+"DefaultIconError.png")







#Зареждане на видео
def VIDEOLINKS(url):
		try:
			#http://api.vbox7.com/v4/?action=r_video_play&video_md5=933850bd72&app_token=imperia_android_0.0.7_4yxmKd
			jsonrsp = json.loads('{'+urllib2.urlopen(api4 + 'r_video_play&video_md5=' + url + token4).read().split('{', 1)[-1])
			#print jsonrsp['items'][0]['video_title'].encode('utf-8', 'ignore')
			#print jsonrsp['items'][0]['video_location_fallback']
			#print jsonrsp['items'][0]['video_location_ld']
			#print jsonrsp['items'][0]['video_location']
			#print jsonrsp['items'][0]['video_subtitles_path']
			#print jsonrsp['items'][0]['video_thumbnails']['big']
			
			try:
				#Конвертиране на субтитрите в SRT формат
				if not (jsonrsp['items'][0]['video_subtitles_path'] == ''):
					#response = urllib2.urlopen('http://vbox7.com/etc/ext.do?key='+url)
					response = urllib2.urlopen(jsonrsp['items'][0]['video_subtitles_path'])
					#print response.read()
					#subs = urllib.unquote_plus(response.read())
					subs = response.read().split("var sSubsJson = '", 1)[-1].split("';", 1)[0].decode('utf8').encode('raw_unicode_escape').decode('utf8', 'ignore').encode('utf8', 'ignore').replace("\\", "")
					#s = re.compile('{"s":"(.*?)","t"\:(\d+),"f"\:(\d+)}')
					s = re.compile('{"s":"(.+?)","t":(\d+),"f":(\d+)}')
					items = s.findall(subs)
					row = 0
					subs = ''
					for i in items:
						row = row + 1
						subs += str(row) +'\n'
						subs += time.strftime("%H:%M:%S,000", time.gmtime(int(i[2]))) + ' --> ' + time.strftime("%H:%M:%S,000", time.gmtime(int(i[1]))) + '\n'
						#subs += i[0].decode('string_escape').replace('+',' ').replace('<br>','\n')
						subs += i[0].replace('+',' ').replace('<br>','\n')
						subs += '\n\n'
					#print subs
					st = 'true'
					with open(srtsubs_path, "w") as subfile:
						subfile.write(subs)
				else:
					st = 'false'
			except:
				st = 'false'
			
			#Пренастройка качеството на видеото
			if qualityset == '1080p':
				kl = jsonrsp['items'][0]['video_location'].replace('_720','_1080')
			elif qualityset == '720p':
				kl = jsonrsp['items'][0]['video_location']
			elif qualityset == '480p':
				kl = jsonrsp['items'][0]['video_location'].replace('_720','_480')
			elif qualityset == '240p':
				kl = jsonrsp['items'][0]['video_location'].replace('_720','_240')
			else:
				kl = jsonrsp['items'][0]['video_location']
			
			#Проверяваме дали е достъпно предпочитаното качество
			try:
				tconnection = urllib2.Request(kl)
				tconnection.add_header('User-Agent', UA)
				tconnection.get_method = lambda : 'HEAD'
				response = urllib2.urlopen(tconnection)
				response.close()
				kl = kl + '|User-Agent=stagefright&Referer=https://www.vbox7.com'
			except:
				kl = jsonrsp['items'][0]['video_location'] + '|User-Agent=stagefright&Referer=https://www.vbox7.com'
			
			#Възпроизвеждане на видеото
			li = xbmcgui.ListItem(iconImage=jsonrsp['items'][0]['video_thumbnails']['big'], thumbnailImage=jsonrsp['items'][0]['video_thumbnails']['big'], path=kl)
			li.setInfo('video', { 'title': jsonrsp['items'][0]['video_title'].encode('utf-8', 'ignore'), "Plot": jsonrsp['items'][0]['video_description'].encode('utf-8', 'ignore') })
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
			
			#Задаване на субтитри, ако има такива или изключването им
			if st=='true':
				while not xbmc.Player().isPlaying():
					xbmc.sleep(1000) #wait until video is being played
					xbmc.Player().setSubtitles(srtsubs_path)
			else:
				xbmc.Player().showSubtitles(False)
			
		except:
			#print 'VBOX7 Addon Error: не е открито видеото по ID>' + url + ' , затова пренасочвам към windows error...'
			#VIDEOLINKS('be1e5e8dcb')
			xbmc.executebuiltin("Notification(VBOX7,Този клип е личен!,4000)")
			#Възпроизвеждане на празно видео
			li = xbmcgui.ListItem(iconImage=md+'OverlayLocked.png', thumbnailImage=md+'OverlayLocked.png', path='http://m.vbox7.com/blank.mp4|User-Agent=stagefright&Referer=https://www.vbox7.com')
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
		
		
		
		

#Търсачка
def SEARCH(url):
		#Отваряне на предишната заявка за търсене
		searchfile=xbmcvfs.File(search_path)
		result = searchfile.read()
		searchfile.close()
		
		keyb = xbmc.Keyboard(result, 'Търсачка на клипове')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText())
			url= url + searchText + '&page=1'
			url = url.encode('utf-8')
			#print 'SEARCHING:' + url
			
			#Записване на заявката за търсене
			searchfile=xbmcvfs.File(search_path, 'w')
			result = searchfile.write(keyb.getText())
			searchfile.close()
			
			INDEX(url.lower())
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',md+"DefaultFolderBack.png")


#Каталог с корейски сериали
def KORCAT(url):
		try:
			data = urllib2.urlopen('http://shineegirlbg.blogspot.com/p/blog-page_1939.html')
			#print data.read()
			
			#match = re.compile('>(.+?)-&gt.*<a href="http://vbox7.com/.*\D:(.+?)"').findall(data.read())
			match = re.compile(':(\d*)\D>(.+?)</a>').findall(data.read())
			for cid,title in match:
				name = title.encode('utf-8', 'ignore')
				name = name.replace("<b>", "")
				name = name.replace("</b>", "")
				#name = name.replace("<br />", "")
				#name = name.replace('<span style="font-size: large;">', "")
				#name = name.replace("</span>", "")
				name = name.replace("&nbsp;", "")
				#cid = cid.replace("#_=_", "")
				adress = 'r_user_collection&id=' + cid + '&page=1'
				if not ('http' in name):
					addDir(name,adress,1,'')
		except:
			xbmc.executebuiltin("Notification(VBOX7,Няма връзка със сървъра!,4000)")
			addDir('Проверете интернет връзката и опитайте отново','','',md+"DefaultIconError.png")

#Търсачка на колекции
def SEARCHCOLLECTIONS(url):
		#Отваряне на предишната заявка за търсене
		kolfile=xbmcvfs.File(kolekcii_path)
		result = kolfile.read()
		kolfile.close()
		
		keyb = xbmc.Keyboard(result, 'Търсачка на колекции')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText())
			url= url + searchText + '&page=1'
			url = url.encode('utf-8')
			#print 'Adres za tursene na kolekciqta:' + url
			
			#Записване на заявката за търсене
			kolfile=xbmcvfs.File(kolekcii_path, 'w')
			result = kolfile.write(keyb.getText())
			kolfile.close()
			
			LISTCOLLECTIONS(url.lower())
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',md+"DefaultFolderBack.png")

#Разлистване на колекциите от търсачката на колекции
def LISTCOLLECTIONS(url):
			req = urllib2.Request(url)
			req.add_header('User-Agent', UA)
			req.add_header('Referer', 'https://vbox7.com/')
			response = urllib2.urlopen(req)
			data=response.read()
			response.close()
			#print data
			
			match = re.compile('data-id=\"(\d*)\" data-order=\"date\" data-p=\"playlist\" title=\"(.+?)\">').findall(data)
			for cid,title in match[::2]:
				#title = title.encode('utf-8', errors='ignore')
				#cid = re.match( r'.*coll_(.*?)_avatar.*', thumbnail, re.M|re.I)
				adress = 'r_user_collection&id=' + cid + '&page=1'
				#print 'title:' + title
				#addDir(title,adress,1,'http'+thumbnail)
				addDir(title,adress,1,md+"DefaultFolder.png")


#Зареждане на клип по неговото ID
def LOADBYID():
		keyb = xbmc.Keyboard('', 'Въведете ID на видеото http://vbox7.com/play:xxxx')
		keyb.doModal()
		if (keyb.isConfirmed()):
			vid = urllib.quote_plus(keyb.getText())
			#print 'LOADBYID:' + vid
			VIDEOLINKS(vid)
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',md+"DefaultFolderBack.png")

#Прилагане на настройките на приставката при първо въвеждане
def SETTINGS():
		try:
			xbmcaddon.Addon(id='plugin.video.vbox7').openSettings()
			xbmc.executebuiltin("Container.Refresh")
		except:
			print 'VBOX7 Addon Error: грешка при излизане от диалога за настройки или опресняване на главното меню'

#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,vd,hd,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
		liz.setInfo( type="Video", infoLabels={ "Duration": vd } )
		#liz.setInfo( type="Video", infoLabels={ "Plot": "Това е plot","PlotOutline": "Това е plotoutline","Tagline": "Това е tagline","Duration": vd } )
		if hd==1:
			liz.addStreamInfo('video', { 'width': 1280, 'height': 720 })
			liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
		else:
			liz.addStreamInfo('video', { 'width': 720, 'height': 480 })
			liz.addStreamInfo('video', { 'aspect': 1.5, 'codec': 'h264' })
		liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
		liz.setProperty('IsPlayable' , 'true')
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
mode=None

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		INDEX(url)
		
elif mode==2:
		VIDEOLINKS(url)

elif mode==3:
		SEARCH(url)

elif mode==4:
		INDEXCOLLECTIONS(url)

elif mode==5:
		SEARCHCOLLECTIONS(url)

elif mode==6:
		LISTCOLLECTIONS(url)

elif mode==7:
		LOADBYID()

elif mode==8:
		SETTINGS()

elif mode==9:
		KLASATZII(url)
		
elif mode==10:
		USERV(url)

elif mode==11:
		KORCAT(url)

elif mode==12:
		LISTCHANNELS(url)

elif mode==13:
		LISTUSERS(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

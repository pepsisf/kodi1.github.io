# -*- coding: utf-8 -*- 

import re
import os
import sys
import urllib
import urllib2
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import unicodedata

__addon__ = xbmcaddon.Addon()
__author__     = __addon__.getAddonInfo('author')
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__version__    = __addon__.getAddonInfo('version')
__language__   = __addon__.getLocalizedString

__cwd__        = xbmc.translatePath( __addon__.getAddonInfo('path') ).decode("utf-8")
__profile__    = xbmc.translatePath( __addon__.getAddonInfo('profile') ).decode("utf-8")
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) ).decode("utf-8")
__temp__       = xbmc.translatePath( os.path.join( __profile__, 'temp') ).decode("utf-8")

sys.path.append (__resource__)
try:
    os.mkdir(xbmc.translatePath('special://temp/Bukvi/'))
except:
    pass
subpath = xbmc.translatePath('special://temp/Bukvi/')
subarch = xbmc.translatePath('special://temp/Bukvi/subtitle.rar')
subfile = xbmc.translatePath('special://temp/Bukvi/bukvi.Bulgarian.srt')
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:58.0) Gecko/20100101 Firefox/58.0'

def Search(item):

  #### Do whats needed to get the list of subtitles from service site
  #### use item["some_property"] that was set earlier
  #### once done, set xbmcgui.ListItem() below and pass it to xbmcplugin.addDirectoryItem()
  arg = re.sub('\.(.+)', '', item['title']).replace('.','+')
  req = urllib2.Request('http://bukvi.bg/index.php?search='+arg)
  #print 'http://bukvi.bg/index.php?search='+arg
  req.add_header('User-Agent', UA)
  response = urllib2.urlopen(req)
  link=response.read()
  response.close()
  #print link

  matchs = re.compile('<a href=\"/load/(.+?)\">(.+?)</a><span class=\"tooltiptext\"').findall(link)
  for id, sn in matchs:
    durl = 'http://bukvi.mmcenter.bg/load/0-0-0-' + id + '-20'


  
    listitem = xbmcgui.ListItem(label="Bulgarian",                                                                          # language name for the found subtitle
                              label2=sn.decode('utf8', 'ignore').encode('utf8', 'ignore'),                                  # file name for the found subtitle
                              iconImage="4",                                                                                # rating for the subtitle, string 0-5
                              thumbnailImage="bg"                                                                           # language flag, ISO_639_1 language + gif extention, e.g - "en.gif"
                              )
                              
    listitem.setProperty( "sync",        '{0}'.format("false").lower() )  # set to "true" if subtitle is matched by hash,
                                                                       # indicates that sub is 100 Comaptible
                                                                      
    listitem.setProperty( "hearing_imp", '{0}'.format("false").lower() ) # set to "true" if subtitle is for hearing impared
  
  
  ## below arguments are optional, it can be used to pass any info needed in download function
  ## anything after "action=download&" will be sent to addon once user clicks listed subtitle to downlaod
    url = "plugin://%s/?action=download&link=%s&ID=%s&filename=%s" % (__scriptid__,
                                                                    durl,
                                                                    id,
                                                                    sn)
  ## add it to list, this can be done as many times as needed for all subtitles found
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=False) 


def Download(id,link,filename):
    subtitle_list = []

    try:
        os.remove(xbmc.translatePath('special://temp/Bukvi/*.*'))
        os.remove(xbmc.translatePath('special://temp/Bukvi/*.rar'))
        os.remove(xbmc.translatePath('special://temp/Bukvi/*.srt'))
        os.remove(xbmc.translatePath('special://temp/Bukvi/*.sub'))
        os.remove(xbmc.translatePath('special://temp/Bukvi/bukvi.Bulgarian.srt'))
    except:
        pass
    urllib.urlretrieve(link, subarch)
  

    #Разархивираме субтитри с rarfile
    try:
        import rarfile
        archive = rarfile.RarFile(subarch)
        archive.extract(subpath)
    except:
    #Или през XBMC
        try:
            xbmc.executebuiltin(('XBMC.Extract("%s","%s")' % (subarch, subpath)).encode('utf-8'), True)
        except:
            pass
    xbmc.sleep(3000)
    files = os.listdir(subpath)
    patern = '.*\.(srt|sub)$'
    for filename in files:
        if re.match(patern, filename):
            file = subpath + filename
            os.rename(file, subfile)

    subtitle_list.append(subfile) # this can be url, local path or network path.
  
    return subtitle_list



def normalizeString(str):
  return unicodedata.normalize(
         'NFKD', unicode(unicode(str, 'utf-8'))
         ).encode('ascii','ignore')    
 
def get_params():
  param=[]
  paramstring=sys.argv[2]
  if len(paramstring)>=2:
    params=paramstring
    cleanedparams=params.replace('?','')
    if (params[len(params)-1]=='/'):
      params=params[0:len(params)-2]
    pairsofparams=cleanedparams.split('&')
    param={}
    for i in range(len(pairsofparams)):
      splitparams={}
      splitparams=pairsofparams[i].split('=')
      if (len(splitparams))==2:
        param[splitparams[0]]=splitparams[1]
                                
  return param

params = get_params()

#print params


if params['action'] == 'search':
  item = {}
  item['temp']               = False
  item['rar']                = False
  item['year']               = xbmc.getInfoLabel("VideoPlayer.Year")                           # Year
  item['season']             = str(xbmc.getInfoLabel("VideoPlayer.Season"))                    # Season
  item['episode']            = str(xbmc.getInfoLabel("VideoPlayer.Episode"))                   # Episode
  item['tvshow']             = normalizeString(xbmc.getInfoLabel("VideoPlayer.TVshowtitle"))   # Show
  item['title']              = normalizeString(xbmc.getInfoLabel("VideoPlayer.OriginalTitle")) # try to get original title
  item['file_original_path'] = urllib.unquote(xbmc.Player().getPlayingFile().decode('utf-8'))  # Full path of a playing file
  item['3let_language']      = []
  
  for lang in urllib.unquote(params['languages']).decode('utf-8').split(","):
    item['3let_language'].append(xbmc.convertLanguage(lang,xbmc.ISO_639_2))
  
  if item['title'] == "":
    item['title']  = normalizeString(xbmc.getInfoLabel("VideoPlayer.Title"))      # no original title, get just Title
    
  if item['episode'].lower().find("s") > -1:                                      # Check if season is "Special"
    item['season'] = "0"                                                          #
    item['episode'] = item['episode'][-1:]
  
  if ( item['file_original_path'].find("http") > -1 ):
    item['temp'] = True

  elif ( item['file_original_path'].find("rar://") > -1 ):
    item['rar']  = True
    item['file_original_path'] = os.path.dirname(item['file_original_path'][6:])

  elif ( item['file_original_path'].find("stack://") > -1 ):
    stackPath = item['file_original_path'].split(" , ")
    item['file_original_path'] = stackPath[0][8:]
  
  Search(item)

if params['action'] == 'manualsearch':
    item = {}
    item['title'] = urllib.unquote(params['searchstring'])
    Search(item)

elif params['action'] == 'download':
  ## we pickup all our arguments sent from def Search()
  subs = Download(params["ID"],params["link"],params["filename"])
  ## we can return more than one subtitle for multi CD versions, for now we are still working out how to handle that in XBMC core
  for sub in subs:
    listitem = xbmcgui.ListItem(label=sub)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=sub,listitem=listitem,isFolder=False)
  
  
xbmcplugin.endOfDirectory(int(sys.argv[1])) ## send end of directory to XBMC